
#include "log.hpp"

#include <stdarg.h>
#include <stdio.h>
#include <list>

using namespace std;


static const int LOG_BUF_LEN = 1024 * 512 + 50;
static const int TEMP_BUF_LEN = 1024 * 512;
static char logbuf[LOG_BUF_LEN];
static char tempbuf[LOG_BUF_LEN];

static list<string> ignore_log;


static bool check_ignore(const char *buf, int size)
{
	list<string>::iterator it;
	for(it = ignore_log.begin(); it != ignore_log.end(); it++)
	{
		if(size < it->size())
			continue;

		const char *chr = it->c_str();
		bool doo = true;
		for(int i = 0, count = it->size(); i < count; i++)
		{
			if(buf[i] != chr[i])
				doo = false;
		}

		if(doo)
			return true;
	}

	return false;
}

void log_print(const char *fmt, ...)
{
	va_list arglist;
	va_start(arglist, fmt);
	vsnprintf(tempbuf, TEMP_BUF_LEN, fmt, arglist); 
	va_end(arglist);

	if(check_ignore(tempbuf, TEMP_BUF_LEN))
		return;

	snprintf(logbuf, LOG_BUF_LEN, "%s\r\n", tempbuf); 

	fprintf(stderr, logbuf);
}

void log_add_ignore(string str)
{
	ignore_log.push_back(str);
}


