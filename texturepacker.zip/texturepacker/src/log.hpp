
#ifndef _LOG_H_
#define _LOG_H_

#include <string>

using namespace std;


void log_print(const char *fmt, ...);
void log_add_ignore(string str);


#endif

