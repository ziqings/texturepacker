
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <list>
#include <string>
#include <sys/stat.h>

#include "gdef.hpp"

using namespace std;


static bool combinedirfile(const char *dir, const char *file, char *out, size_t size)
{
	int dirLen = strlen(dir);
	int fileLen = strlen(file);
	if(dirLen + fileLen + 1 >= (int)size)
		return false;

	strcpy(out, dir);
	if(out[dirLen - 1] != '/')
	{
		out[dirLen] = '/';
		out[dirLen + 1] = '\0';
	}
	strcat(out, file);

	return true;
}

bool util_listfiles(const char *dir, list<string> &lst)
{
	DIR *dp = opendir(dir);
	if(dp == NULL)
	{
		fprintf(stderr, "failed to open dir: %s\n", dir);
		return false;
	}

	for(struct dirent *ep = readdir(dp); ep != NULL; ep = readdir(dp))
	{
		if(strcmp(ep->d_name, ".") == 0 || strcmp(ep->d_name, "..") == 0)
			continue;

		char file[MAXPATH];
		if(!combinedirfile(dir, ep->d_name, file, sizeof(file)))
		{
			fprintf(stderr, "Failed to process %s in %s\n", ep->d_name, dir);
			closedir(dp);
			return false;
		}

		struct stat att;
		if(stat(file, &att) == -1)
		{
			fprintf(stderr, "Failed to get att of %s\n", file);
			closedir(dp);
			return false;
		}

		if(S_ISDIR(att.st_mode))
		{
			if(!util_listfiles(file, lst))
			{
				closedir(dp);
				return false;
			}
		}
		else if(S_ISREG(att.st_mode))
		{
			if(att.st_size == 0)
				continue;

			lst.push_back(string(file));
		}
		else
		{
			fprintf(stderr, "Invalid file: %s\n", file);
		}
	}

	closedir(dp);
	return true;
}

