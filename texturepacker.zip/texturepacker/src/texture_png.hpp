
#ifndef _TEXTURE_PNG_H_
#define _TEXTURE_PNG_H_

#include "png.h"


class texture_png
{
	public:
		texture_png(const char *name);
		~texture_png();

		int open_read();
		int read_info();
		int read_data(unsigned char *arr, int size);

		int open_write();
		int write_info();
		int write_data(unsigned char *data, int data_size);
		void close();

		void copy_info(texture_png *dest);

		inline unsigned int get_width(){return m_width;}
		inline void set_width(unsigned int v){m_width = v;}

		inline unsigned int get_height(){return m_height;}
		inline void set_height(unsigned int v){m_height = v;}

		inline int get_bit_depth(){return m_bit_depth;}
		inline void set_bit_depth(int v){m_bit_depth = v;}

		inline int get_color_type(){return m_color_type;}
		inline void set_color_type(int v){m_color_type = v;}


	private:
		void destroy_png_ptr();
		void set_png_ptr();


	private:
		char m_file_name[256];
		png_structp m_png_ptr;
		png_infop m_png_info_ptr;
		FILE *m_fp;

		//IHDR
		bool m_ihdr_valid;
		unsigned int m_width, m_height;
		int m_bit_depth, m_color_type, m_compression_type, m_filter_type;

		//cHRM
		bool m_chrm_valid;
		png_fixed_point m_white_x, m_white_y, m_red_x, m_red_y, m_green_x, m_green_y, m_blue_x, m_blue_y;

		//gAMA
		bool m_gama_valid;
		png_fixed_point m_gama;

		//iCCP
		bool m_iccp_valid;
		png_charp m_iccp_name;
		int m_iccp_compression_type;
		png_bytep m_iccp_profile;
		png_uint_32 m_iccp_proflen;

		//sRGB
		bool m_srgb_valid;
		int m_intent;

		//PLTE
		bool m_plte_valid;
		png_colorp m_palette;
		int m_num_palette;

		//bKGD
		bool m_bkgd_valid;
		png_color_16p m_background;

		//hIST
		bool m_hist_valid;
		png_uint_16p m_hist;

		//oFFs
		bool m_offs_valid;
		png_int_32 m_offset_x, m_offset_y;
		int m_unit_type;

		//pCAL
		bool m_pcal_valid;
		png_charp m_pcal_purpose, m_pcal_units;
		png_charpp m_pcal_params;
		png_int_32 m_pcal_x0, m_pcal_x1;
		int m_pcal_type, m_pcal_nparams;

		//pHYs
		bool m_phys_valid;
		png_uint_32 m_phys_res_x, m_phys_res_y;
		int m_phys_unit_type;

		//sBIT
		bool m_sbit_valid;
		png_color_8p m_sig_bit;

		//sCAL
		bool m_scal_valid;
		int m_scal_unit;
		png_charp m_scal_width, m_scal_height;

		//iTXt
		bool m_itxt_valid;
		png_textp m_text_ptr;
		int m_num_text;

		//tIME
		bool m_time_valid;
		png_timep m_mod_time;

		//tRNS
		bool m_trns_valid;
		png_bytep m_trans_alpha;
		int m_num_trans;
		png_color_16p m_trans_color;
};


#endif

