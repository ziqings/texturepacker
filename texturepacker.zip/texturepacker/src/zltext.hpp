
#ifndef _ZLTEXT_H_
#define _ZLTEXT_H_

#include <list>
#include <string>
#include <memory.h>
#include <map>

using namespace std;


class zltext_c
{
	public:
		zltext_c(const char *filepath);
		~zltext_c();

		bool read(const char *key, list<string> &lst);

		bool write(map<string, list<string> > &data);
		//bool Read(const char *key, char *arr, int arrlen, int &resultLen);
	
	private:
		char m_filepath[1024];
};

#endif


