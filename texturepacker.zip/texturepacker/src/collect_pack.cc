
#include "collect_pack.hpp"
#include "util.hpp"
#include "texture_png.hpp"
#include "log.hpp"

#include <string.h>


collect_pack::collect_pack()
{
	m_valid_suffix.push_back("PNG");
	m_valid_suffix.push_back("png");

	m_all_info = NULL;
}

collect_pack::~collect_pack()
{
	if(m_all_info != NULL)
	{
		delete[] m_all_info;
		m_all_info = NULL;
	}
}

bool collect_pack::check_valid_name(const char *name)
{
	int len = strlen(name);
	const char *curstr;

	list<string>::iterator it;
	for(it = m_valid_suffix.begin(); it != m_valid_suffix.end(); it++)
	{
		curstr = it->c_str();
		int curlen = strlen(curstr);
		if(curlen == 0)
			continue;

		if(curlen == len)
		{
			bool doo = false;
			for(int i = 0; i < len; i++)
			{
				if(name[i] != curstr[i])
				{
					doo = true;
					break;
				}
			}

			if(!doo)
			{
				return true;
			}
		}
	}

	return false;
}

bool collect_pack::check_valid_file(const char *file)
{
	int len = strlen(file);
	if(len > 0)
	{
		char c;
		int index = -1;
		for(int i = len - 1; i >= 0; i--)
		{
			c = file[i];
			if(c == '.')
			{
				index = i + 1;
				break;
			}
		}

		if(index > 0 && index < len)
		{
			return check_valid_name(&(file[index]));
		}
	}

	return false;
}

void collect_pack::collect(const char *root_path)
{
	list<string> allfiles;
	util_listfiles(root_path, allfiles);

	list<string>::iterator file_it;
	for(file_it = allfiles.begin(); file_it != allfiles.end(); file_it++)
	{
		if(check_valid_file((*file_it).c_str()))
		{
			m_all_files.push_back(*file_it);
		}
	}
}

int collect_pack::read_collect_info()
{
	int size = m_all_files.size();
	if(size <= 0)
		return -1;
	m_all_info = new rect[size];

	list<string>::iterator it;
	int re = -1;
	int index = 0;
	for(it = m_all_files.begin(); it != m_all_files.end(); it++)
	{
		texture_png tp(it->c_str());
		re = tp.open_read();
		if(re < 0)
		{
			log_print("collect png file open read failed->%d, %s", re, it->c_str());
			return -2;
		}

		re = tp.read_info();
		if(re < 0)
		{
			log_print("collect png file read info failed->%d, %s", re, it->c_str());
			return -3;
		}

		rect *rt = &m_all_info[index];
		rt->width = tp.get_width();
		rt->height = tp.get_height();
		tp.close();

		index++;
	}

	return 0;
}


