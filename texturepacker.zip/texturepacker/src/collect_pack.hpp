
#ifndef _COLLECT_PACK_H_
#define _COLLECT_PACK_H_

#include <list>
#include <string>

#include "math.hpp"

using namespace std;


class collect_pack
{
	public:
		collect_pack();
		~collect_pack();

		void collect(const char *root_path);
		int read_collect_info();

		inline int get_all_size(){return m_all_files.size();}
		inline rect * get_all_info(){return m_all_info;}
		inline list<string> & get_all_files(){return m_all_files;}

	private:
		bool check_valid_name(const char *name);
		bool check_valid_file(const char *file);

	private:
		list<string> m_all_files;
		rect *m_all_info;
		list<string> m_valid_suffix;
};


#endif


