
#include "texture_pack.hpp"
#include "log.hpp"

#include <stdlib.h>
#include <vector>

using namespace std;


texture_pack::texture_pack()
{
	m_pack_items = NULL;
}

texture_pack::~texture_pack()
{
	list<rect *>::iterator it = m_ar_list.begin();
	while(it != m_ar_list.end())
	{
		del_rect(*it);
		it++;
	}

	m_ar_list.clear();

	it = m_ar1_list.begin();
	while(it != m_ar1_list.end())
	{
		del_rect(*it);
		it++;
	}
}

rect * texture_pack::get_rect()
{
	return new rect();
}

void texture_pack::del_rect(rect *rt)
{
	if(rt != NULL)
	{
		delete rt;
	}
}

int texture_pack::pack(unsigned int width, unsigned int height, rect *arr, unsigned int size)
{
	if(width <= 0 || height <= 0)
		return -1;
	if(arr == NULL)
		return -2;
	if(size <= 0)
		return -3;

	rect *rect = get_rect();
	rect->x = 0;
	rect->y = 0;
	rect->width = width;
	rect->height = height;

	m_ar_list.push_back(rect);

	m_pack_items = arr;

	return pack(size);
}

int texture_pack::pack(unsigned int size)
{
	vector<rect *> m_width_vec;
	vector<rect *> m_height_vec;

	int i, j;

	for(i = 0; i < size; i++)
	{
		m_width_vec.push_back(&m_pack_items[i]);
		m_height_vec.push_back(&m_pack_items[i]);
	}

	for(i = 0; i < size; i++)
	{
		for(j = i + 1; j < size; j++)
		{
			rect *p = m_width_vec[i];
			rect *p1 = m_width_vec[j];
			
			if(p1->width > p->width)
			{
				m_width_vec[i] = p1;
				m_width_vec[j] = p;
			}

			p = m_height_vec[i];
			p1 = m_height_vec[j];
			if(p1->height > p->height)
			{
				m_height_vec[i] = p1;
				m_height_vec[j] = p;
			}
		}
	}

	m_pack_list.clear();

	if(m_width_vec[0]->width > m_height_vec[0]->height)
	{
		m_width_pack = false;
		for(i = 0; i < size; i++)
		{
			m_pack_list.push_back(m_width_vec[i]);
		}
	}
	else
	{
		m_width_pack = true;
		for(i = 0; i < size; i++)
		{
			m_pack_list.push_back(m_height_vec[i]);
		}
	}

	m_pack_num = 0;
	return pack();
}

int texture_pack::pack()
{
	if(m_pack_list.empty())
		return 0;

	if(m_ar_list.empty() && m_ar1_list.empty())
		return -1;

	if(m_pack_num > 10000)
		return -2;

	rect *item = m_pack_list.front();
	m_pack_list.pop_front();

	bool packed = false;

	adjust(item, m_ar_list, packed, true, 1);
	if(!packed && !m_ar_list.empty())
	{
		adjust(item, m_ar_list, packed, true, 1.1f);
		if(!packed)
			adjust(item, m_ar_list, packed, true, 1.2f);
		if(!packed)
			adjust(item, m_ar_list, packed, true, 1.5f);
		if(!packed)
			adjust(item, m_ar_list, packed, false, 1);
	}

	if(!packed)
		adjust(item, m_ar1_list, packed, true, 1.2f);
	if(!packed)
		adjust(item, m_ar1_list, packed, true, 1.5f);
	if(!packed)
		adjust(item, m_ar1_list, packed, false, 1);

	if(!packed)
		return -3;

	return pack();
}

void texture_pack::adjust(rect *item, list<rect *> &rect_list, bool &packed, bool strict, float scale)
{
	float sw, sh;
	if(strict)
	{
		sw = item->width * scale;
		sh = item->height * scale;
	}

	rect *add = NULL;
	rect *add1 = NULL;

	list<rect *>::iterator it = rect_list.begin();

	unsigned int ih, iw, pv;
	bool doo;
	for(; it != rect_list.end(); it++)
	{
		if(strict && ((*it)->width > sw && (*it)->height > sh))
		{
			continue;
		}
		else if((*it)->width < item->width || (*it)->height < item->height)
		{
			continue;
		}

		item->x = (*it)->x;
		item->y = (*it)->y;

		ih = (*it)->height - item->height;
		iw = (*it)->width - item->width;

		if((*it)->height > 30 && (*it)->width > 30)
		{
			doo = true;
			if(m_width_pack)
			{
				pv = item->width;
				if(pv < 30)
					pv = 30;
				if(pv > (*it)->width)
				{
					pv = (*it)->width;
					doo = false;
				}

				if(ih > 10)
				{
					add = get_rect();
					add->x = (*it)->x;
					add->y = (*it)->y + item->height;
					add->width = pv;
					add->height = ih;
				}

				if(doo && iw > 10)
				{
					add1 = get_rect();
					add1->x = (*it)->x + pv;
					add1->y = (*it)->y;
					add1->width = (*it)->width - pv;
					add1->height = (*it)->height;
				}
			}
			else
			{
				pv = item->height;
				if(pv < 30)
					pv = 30;
				if(pv > (*it)->height)
				{
					pv = (*it)->height;
					doo = false;
				}

				if(iw > 10)
				{
					add = get_rect();
					add->x = (*it)->x + item->width;
					add->y = (*it)->y;
					add->width = iw;
					add->height = pv;
				}
				if(doo && ih > 10)
				{
					add1 = get_rect();
					add1->x = (*it)->x;
					add1->y = (*it)->y + pv;
					add1->width = (*it)->width;
					add1->height = (*it)->height - pv;
				}
			}
		}
		else
		{
			if((*it)->height <= 30)
			{
				if(iw > 10)
				{
					add = get_rect();
					add->x = (*it)->x + item->width;
					add->y = (*it)->y;
					add->width = iw;
					add->height = (*it)->height;
				}
			}
			else
			{
				if(ih > 10)
				{
					add = get_rect();
					add->x = (*it)->x;
					add->y = (*it)->y + item->height;
					add->width = (*it)->width;
					add->height = ih;
				}
			}
		}

		packed = true;
		break;
	}

	if(packed)
	{
		rect_list.erase(it);
		if(add != NULL)
			m_ar_list.push_front(add);
		if(add1 != NULL)
		{
			if(add1->width <= 50 && add1->height <= 50)
				m_ar_list.push_back(add1);
			else
				m_ar1_list.push_front(add1);
		}
	}
}


