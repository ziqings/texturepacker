
#include "texture_png.hpp"
#include "log.hpp"

#include <string.h>
#include <stdlib.h>


texture_png::texture_png(const char *name)
{
	if(name == NULL)
	{
		m_file_name[0] = '\0';
	}
	else
	{
		int len = strlen(name);
		if(len < 256)
		{
			memcpy(m_file_name, name, len);
			m_file_name[len] = '\0';
		}
		else
		{
			m_file_name[0] = '\0';
		}
	}

	m_fp = NULL;
	m_png_ptr = NULL;
	m_png_info_ptr = NULL;
	m_width = m_height = 0;
	m_bit_depth = m_color_type = -1;

	m_ihdr_valid = false;
	m_chrm_valid = false;
	m_gama_valid = false;
	m_iccp_valid = false;
	m_srgb_valid = false;
	m_plte_valid = false;
	m_bkgd_valid = false;
	m_hist_valid = false;
	m_offs_valid = false;
	m_pcal_valid = false;
	m_phys_valid = false;
	m_sbit_valid = false;
	m_scal_valid = false;
	m_itxt_valid = false;
	m_time_valid = false;
	m_trns_valid = false;
}

texture_png::~texture_png()
{
	close();
	m_width = m_height = 0;
	m_bit_depth = m_color_type = -1;
}

static void png_warning_func(png_structp ptr, png_const_charp str)
{
}


static void png_error_func(png_structp ptr, png_const_charp str)
{
	log_print(str);
}

void texture_png::destroy_png_ptr()
{
	if(m_png_info_ptr != NULL && m_png_ptr != NULL)
	{
		png_destroy_read_struct(&m_png_ptr, &m_png_info_ptr, NULL);
		m_png_ptr = NULL;
		m_png_info_ptr = NULL;
		return;
	}

	if(m_png_ptr != NULL)
	{
		png_destroy_read_struct(&m_png_ptr, NULL, NULL);
		m_png_ptr = NULL;
	}
}

void texture_png::set_png_ptr()
{
	if(m_png_ptr != NULL)
	{
		png_set_error_fn(m_png_ptr, NULL, png_error_func, png_warning_func);
	}
}

int texture_png::open_write()
{
	m_fp = fopen(m_file_name, "wb");
	if(!m_fp)
	{
		log_print("open png file for write failed->%s", m_file_name);
		return -1;
	}

	int re;
	m_png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if(!m_png_ptr)
	{
		log_print("create png write struct failed");
		return -2;
	}

	set_png_ptr();

	m_png_info_ptr = png_create_info_struct(m_png_ptr);
	if(!m_png_info_ptr)
	{
		log_print("create png info write struct failed");
		destroy_png_ptr();
		return -3;
	}

	png_init_io(m_png_ptr, m_fp);

	return 0;
}

int texture_png::write_info()
{
	if(m_png_ptr == NULL)
		return -1;
	if(m_png_info_ptr == NULL)
		return -2;

	if(m_ihdr_valid)
		png_set_IHDR(m_png_ptr, m_png_info_ptr, m_width, m_height, m_bit_depth, m_color_type, PNG_INTERLACE_NONE, m_compression_type, m_filter_type);
	
	if(m_chrm_valid)
		png_set_cHRM_fixed(m_png_ptr, m_png_info_ptr, m_white_x, m_white_y, m_red_x, m_red_y, m_green_x, m_green_y, m_blue_x, m_blue_y);

	if(m_gama_valid)
		png_set_gAMA_fixed(m_png_ptr, m_png_info_ptr, m_gama);

	if(m_iccp_valid)
		png_set_iCCP(m_png_ptr, m_png_info_ptr, m_iccp_name, m_iccp_compression_type, NULL, 0);

	if(m_srgb_valid)
		png_set_sRGB(m_png_ptr, m_png_info_ptr, m_intent);

	if(m_plte_valid)
		png_set_PLTE(m_png_ptr, m_png_info_ptr, m_palette, m_num_palette);

	if(m_bkgd_valid)
		png_set_bKGD(m_png_ptr, m_png_info_ptr, m_background);

	if(m_hist_valid)
		png_set_hIST(m_png_ptr, m_png_info_ptr, m_hist);

	if(m_offs_valid)
		png_set_oFFs(m_png_ptr, m_png_info_ptr, m_offset_x, m_offset_y, m_unit_type);

	if(m_pcal_valid)
		png_set_pCAL(m_png_ptr, m_png_info_ptr, m_pcal_purpose, m_pcal_x0, m_pcal_x1, m_pcal_type, m_pcal_nparams, m_pcal_units, m_pcal_params);

	if(m_phys_valid)
		png_set_pHYs(m_png_ptr, m_png_info_ptr, m_phys_res_x, m_phys_res_y, m_phys_unit_type);

	if(m_sbit_valid)
		png_set_sBIT(m_png_ptr, m_png_info_ptr, m_sig_bit);

	if(m_scal_valid)
		png_set_sCAL_s(m_png_ptr, m_png_info_ptr, m_scal_unit, m_scal_width, m_scal_height);

	if(m_itxt_valid)
		png_set_text(m_png_ptr, m_png_info_ptr, m_text_ptr, m_num_text);

	if(m_time_valid)
		png_set_tIME(m_png_ptr, m_png_info_ptr, m_mod_time);

	if(m_trns_valid)
	{
		int m_sample_max = (1 << m_bit_depth);
		if(!((m_color_type == PNG_COLOR_TYPE_GRAY &&
						(int)m_trans_color->gray > m_sample_max) ||
					(m_color_type== PNG_COLOR_TYPE_RGB &&
					 ((int)m_trans_color->red > m_sample_max ||
					  (int)m_trans_color->green > m_sample_max ||
					  (int)m_trans_color->blue > m_sample_max))))
			png_set_tRNS(m_png_ptr, m_png_info_ptr, m_trans_alpha, m_num_trans, m_trans_color);
	}

	png_write_info(m_png_ptr, m_png_info_ptr);
}

int texture_png::write_data(unsigned char *data, int data_size)
{
	if(data == NULL)
		return -1;

	if(data_size <= 0)
		return -2;

	int row_size = m_width * 4;
	if(data_size != row_size * m_height)
		return -3;

	for(int i = 0; i < m_height; i++)
	{
		png_write_row(m_png_ptr, (png_bytep)(data + i * row_size));
	}
	png_write_end(m_png_ptr, m_png_info_ptr);

	return 0;
}

int texture_png::open_read()
{
	m_fp = fopen(m_file_name, "rb");
	if(!m_fp)
	{
		log_print("open png file for read failed->%s", m_file_name);
		return -1;
	}

	int re;
	m_png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if(!m_png_ptr)
	{
		log_print("create png read struct failed");
		return -2;
	}

	set_png_ptr();

	m_png_info_ptr = png_create_info_struct(m_png_ptr);
	if(!m_png_info_ptr)
	{
		log_print("create png info write struct failed");
		destroy_png_ptr();
		return -3;
	}

	png_init_io(m_png_ptr, m_fp);

	return 0;
}

int texture_png::read_info()
{
	if(m_png_ptr == NULL)
		return -1;
	if(m_png_info_ptr == NULL)
		return -2;

	png_read_info(m_png_ptr, m_png_info_ptr);

	if(png_get_IHDR(m_png_ptr, m_png_info_ptr, &m_width, &m_height, &m_bit_depth, &m_color_type, NULL, &m_compression_type, &m_filter_type))
		m_ihdr_valid = true;

	if(png_get_cHRM_fixed(m_png_ptr, m_png_info_ptr, &m_white_x, &m_white_y, &m_red_x, &m_red_y, &m_green_x, &m_green_y, &m_blue_x, &m_blue_y))
		m_chrm_valid = true;

	if(png_get_gAMA_fixed(m_png_ptr, m_png_info_ptr, &m_gama))
		m_gama_valid = true;

	if(png_get_iCCP(m_png_ptr, m_png_info_ptr, &m_iccp_name, &m_iccp_compression_type, &m_iccp_profile, &m_iccp_proflen))
		m_iccp_valid = true;

	if(png_get_sRGB(m_png_ptr, m_png_info_ptr, &m_intent))
		m_srgb_valid = true;

	if(png_get_PLTE(m_png_ptr, m_png_info_ptr, &m_palette, &m_num_palette))
		m_plte_valid = true;

	if(png_get_bKGD(m_png_ptr, m_png_info_ptr, &m_background))
		m_bkgd_valid = true;

	if(png_get_hIST(m_png_ptr, m_png_info_ptr, &m_hist))
		m_hist_valid = true;

	if(png_get_oFFs(m_png_ptr, m_png_info_ptr, &m_offset_x, &m_offset_y, &m_unit_type))
		m_offs_valid = true;

	if(png_get_pCAL(m_png_ptr, m_png_info_ptr, &m_pcal_purpose, &m_pcal_x0, &m_pcal_x1, &m_pcal_type, &m_pcal_nparams, &m_pcal_units, &m_pcal_params))
		m_pcal_valid = true;

	if(png_get_pHYs(m_png_ptr, m_png_info_ptr, &m_phys_res_x, &m_phys_res_y, &m_phys_unit_type))
		m_phys_valid = true;

	if(png_get_sBIT(m_png_ptr, m_png_info_ptr, &m_sig_bit))
		m_sbit_valid = true;

	if(png_get_sCAL_s(m_png_ptr, m_png_info_ptr, &m_scal_unit, &m_scal_width, &m_scal_height))
		m_scal_valid = true;

	if(png_get_text(m_png_ptr, m_png_info_ptr, &m_text_ptr, &m_num_text) > 0)
		m_itxt_valid = true;

	if(png_get_tIME(m_png_ptr, m_png_info_ptr, &m_mod_time))
		m_time_valid = true;

	if(png_get_tRNS(m_png_ptr, m_png_info_ptr, &m_trans_alpha, &m_num_trans, &m_trans_color))
		m_trns_valid = true;

	return 0;
}

int texture_png::read_data(unsigned char *arr, int size)
{
	if(m_height <= 0 || m_width <= 0)
		return -1;

	if(arr == NULL)
		return -2;

	if(m_color_type != PNG_COLOR_TYPE_RGBA)
		return -3;

	unsigned int buf_size = m_width * m_height * 4;
	if(size < buf_size)
		return -4;

	int row_size = m_width * 4;
	for(int i = 0; i < m_height; i++)
	{
		png_read_row(m_png_ptr, (png_bytep)(arr + i * row_size), NULL);
	}

	png_read_end(m_png_ptr, m_png_info_ptr);

	return buf_size;
}

void texture_png::copy_info(texture_png *dest)
{
	if(dest == NULL)
		return;

	dest->m_ihdr_valid = m_ihdr_valid;
	if(m_ihdr_valid)
	{
		dest->m_bit_depth = m_bit_depth;
		dest->m_color_type = m_color_type;
		dest->m_compression_type = m_compression_type;
		dest->m_filter_type = m_filter_type;
	}

	dest->m_chrm_valid = m_chrm_valid;
	if(m_chrm_valid)
	{
		dest->m_white_x = m_white_x;
		dest->m_white_y = m_white_y;
		dest->m_red_x = m_red_x;
		dest->m_red_y = m_red_y;
		dest->m_green_x = m_green_x;
		dest->m_green_y = m_green_y;
		dest->m_blue_x = m_blue_x;
		dest->m_blue_y = m_blue_y;
	}

	dest->m_gama_valid = m_gama_valid;
	if(m_gama_valid)
		dest->m_gama = m_gama;

	dest->m_iccp_valid = m_iccp_valid;
	if(m_iccp_valid)
	{
		dest->m_iccp_name = m_iccp_name;
		dest->m_iccp_compression_type = m_iccp_compression_type;
		dest->m_iccp_profile = m_iccp_profile;
		dest->m_iccp_proflen = m_iccp_proflen;
	}

	dest->m_srgb_valid = m_srgb_valid;
	if(m_srgb_valid)
		dest->m_intent = m_intent;

	dest->m_plte_valid = m_plte_valid;
	if(m_plte_valid)
	{
		dest->m_palette = m_palette;
		dest->m_num_palette = m_num_palette;
	}

	dest->m_bkgd_valid = m_bkgd_valid;
	if(m_bkgd_valid)
		dest->m_background = m_background;

	dest->m_hist_valid = m_hist_valid;
	if(m_hist_valid)
		dest->m_hist = m_hist;

	dest->m_offs_valid = m_offs_valid;
	if(m_offs_valid)
	{
		dest->m_offset_x = m_offset_x;
		dest->m_offset_y = m_offset_y;
		dest->m_unit_type = m_unit_type;
	}

	dest->m_pcal_valid = m_pcal_valid;
	if(m_pcal_valid)
	{
		dest->m_pcal_purpose = m_pcal_purpose;
		dest->m_pcal_units = m_pcal_units;
		dest->m_pcal_params = m_pcal_params;
		dest->m_pcal_x0 = m_pcal_x0;
		dest->m_pcal_x1 = m_pcal_x1;
		dest->m_pcal_type = m_pcal_type;
		dest->m_pcal_nparams = m_pcal_nparams;
	}

	dest->m_phys_valid = m_phys_valid;
	if(m_phys_valid)
	{
		dest->m_phys_res_x = m_phys_res_x;
		dest->m_phys_res_y = m_phys_res_y;
		dest->m_phys_unit_type = m_phys_unit_type;
	}

	dest->m_sbit_valid = m_sbit_valid;
	if(m_sbit_valid)
		dest->m_sig_bit = m_sig_bit;

	dest->m_scal_valid = m_scal_valid;
	if(m_scal_valid)
	{
		dest->m_scal_unit = m_scal_unit;
		dest->m_scal_width = m_scal_width;
		dest->m_scal_height = m_scal_height;
	}

	dest->m_itxt_valid = m_itxt_valid;
	if(m_itxt_valid)
	{
		dest->m_text_ptr = m_text_ptr;
		dest->m_num_text = m_num_text;
	}

	dest->m_time_valid = m_time_valid;
	if(m_time_valid)
		dest->m_mod_time = m_mod_time;

	dest->m_trns_valid = m_trns_valid;
	if(m_trns_valid)
	{
		dest->m_trans_alpha = m_trans_alpha;
		dest->m_num_trans = m_num_trans;
		dest->m_trans_color = m_trans_color;
	}
}

void texture_png::close()
{
	destroy_png_ptr();
	if(m_fp != NULL)
	{
		fclose(m_fp);
		m_fp = NULL;
	}
}


