
#ifndef _UTIL_H_
#define _UTIL_H_

#include <list>

using namespace std;


bool util_listfiles(const char *dir, list<string> &lst);

#endif


