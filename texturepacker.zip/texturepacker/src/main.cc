
#include "texture_png.hpp"
#include "texture_pack.hpp"
#include "collect_pack.hpp"
#include "log.hpp"
#include "zltext.hpp"
#include "texture_packer.pb.h"

#include <string.h>
#include <assert.h>
#include <map>

using namespace std;


int main(int argc, char * argv[])
{
	zltext_c zlt("config-tex-pack.zl");
	list<string> lst;
	bool ret  = zlt.read("src_tex_root_dir", lst);
	assert(ret);
	assert(lst.size() == 1);
	string root_path_str = lst.front();
	const char *root_path = root_path_str.c_str();
	int root_path_len = root_path_str.size();

	lst.clear();
	ret = zlt.read("dest_tex_path", lst);
	assert(ret);
	assert(lst.size() == 1);
	string dest_path_str = lst.front();
	const char *dest_path = dest_path_str.c_str();
	
	lst.clear();
	ret = zlt.read("dest_pack_info_bytes", lst);
	assert(ret);
	assert(lst.size() == 1);
	string pack_dest_path_str_bytes = lst.front();
	const char *pack_dest_path_bytes = pack_dest_path_str_bytes.c_str();


	const char *pack_dest_path_zl = NULL;
	lst.clear();
	ret = zlt.read("dest_pack_info_zl", lst);
	if(lst.size() == 1)
	{
		string pack_dest_path_str_zl = lst.front();
		pack_dest_path_zl = pack_dest_path_str_zl.c_str();
	}

	collect_pack collect;
	collect.collect(root_path);
	int re = collect.read_collect_info();
	if(re < 0)
		return 0;

	int all_size = collect.get_all_size();
	if(all_size <= 0)
		return 0;
	rect *all_info = collect.get_all_info();
	if(all_info == NULL)
		return 0;

	int tex_size = 64;
	texture_pack *pack_64 = new texture_pack();
	re = pack_64->pack(64, 64, all_info, all_size);
	delete pack_64;
	if(re < 0)
	{
		tex_size = 128;
		texture_pack *pack_128 = new texture_pack();
		re = pack_128->pack(128, 128, all_info, all_size);
		delete pack_128;
		if(re < 0)
		{
			tex_size = 256;
			texture_pack *pack_256 = new texture_pack();
			re = pack_256->pack(256, 256, all_info, all_size);
			delete pack_256;
			if(re < 0)
			{
				tex_size = 512;
				texture_pack *pack_512 = new texture_pack();
				re = pack_512->pack(512, 512, all_info, all_size);
				delete pack_512;
				if(re < 0)
				{
					tex_size = 1024;
					texture_pack *pack_1024 = new texture_pack();
					re = pack_1024->pack(1024, 1024, all_info, all_size);
					delete pack_1024;
					if(re < 0)
					{
						tex_size = 2048;
						texture_pack *pack_2048 = new texture_pack();
						re = pack_2048->pack(2048, 2048, all_info, all_size);
						delete pack_2048;
						if(re < 0)
						{
							log_print("texture pack failed");
							tex_size = 0;
							return 0;
						}
					}
				}
			}
		}
	}

	if(tex_size > 0)
	{
		list<string> all_files = collect.get_all_files();
		texture_png dest_png(dest_path);
		dest_png.open_write();
		dest_png.set_width(tex_size);
		dest_png.set_height(tex_size);

		int row_size = tex_size * 4;
		int buflen = tex_size * row_size;
		unsigned char *buf = new unsigned char[buflen];
		memset(buf, 0, buflen);

		unsigned char *temp_buf = new unsigned char[buflen];

		list<string>::iterator it;
		int index = 0;
		map<string, list<string> > info_data;
		texture_packer proto_tex_pack;

		char str_buf[256];

		for(it = all_files.begin(); it != all_files.end(); it++)
		{
			texture_png temp(it->c_str());
			temp.open_read();
			temp.read_info();
			if(index == 0)
			{
				temp.copy_info(&dest_png);
			}

			re = temp.read_data(temp_buf, buflen);
			temp.close();
			if(re < 0)
			{
				log_print("read tex data failed->%d, %s", re, it->c_str());
				delete[] buf;
				delete[] temp_buf;
				return 0;
			}

			rect *rt = &all_info[index];
			for(int i = 0; i < rt->height; i++)
			{
				memcpy(buf + (rt->y + i) * row_size + rt->x * 4, temp_buf + i * rt->width * 4, rt->width * 4);
			}

			const char *v = it->c_str();
			int i = 0;
			for(; i < root_path_len; i++)
			{
				if(root_path[i] != v[i])
					break;
			}

			if(i == root_path_len)
			{
				if(v[i] == '/' || v[i] == '\\')
					v = v + i + 1;
				else
					v = v + i;
			}

			list<string> tt;
			sprintf(str_buf, "%d", rt->x);
			tt.push_back(string(str_buf));
			sprintf(str_buf, "%d", rt->y);
			tt.push_back(string(str_buf));
			sprintf(str_buf, "%d", rt->width);
			tt.push_back(string(str_buf));
			sprintf(str_buf, "%d", rt->height);
			tt.push_back(string(str_buf));
			info_data.insert(make_pair<string, list<string> >(string(v), tt));

			proto_tex_pack.add_names(string(v));
			pack_item *pitem = proto_tex_pack.add_items();
			pitem->set_x(rt->x);
			pitem->set_y(rt->y);
			pitem->set_width(rt->width);
			pitem->set_height(rt->height);

			index++;
		}

		dest_png.write_info();
		re = dest_png.write_data(buf, row_size * dest_png.get_height());
		dest_png.close();

		int len = proto_tex_pack.ByteSize();
		proto_tex_pack.SerializeToArray(buf, len);

		FILE *bfp = fopen(pack_dest_path_bytes, "wb");
		if(bfp == NULL)
		{
			log_print("create dest proto bytes file failed->%s", pack_dest_path_bytes);
			return 0;
		}

		fwrite(buf, 1, len, bfp);
		fclose(bfp);

		delete[] buf;
		delete[] temp_buf;

		if(re < 0)
		{
			log_print("write dest tex failed->%d", re);
			return 0;
		}


		if(pack_dest_path_zl)
		{
			zltext_c dest_zlt(pack_dest_path_zl);
			dest_zlt.write(info_data);
		}
	}

	return 0;
}


