
#ifndef _TEXTURE_PACK_H_
#define _TEXTURE_PACK_H_

#include <list>

#include "math.hpp"

using namespace std;


class texture_pack
{
	public:
		texture_pack();
		~texture_pack();

		int pack(unsigned int width, unsigned int height, rect *arr, unsigned int size);

	private:
		rect * get_rect();
		void del_rect(rect *rt);
		int pack(unsigned int size);
		int pack();
		void adjust(rect *item, list<rect *> &rect_list, bool &packed, bool strict, float scale);

	private:
		list<rect *> m_ar_list;
		list<rect *> m_ar1_list;
		rect *m_pack_items;

		list<rect *> m_pack_list;
		bool m_width_pack;
		int m_pack_num;

};

#endif


