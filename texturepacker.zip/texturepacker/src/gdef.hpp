

#ifndef _GDEF_H_
#define _GDEF_H_

#define MAXNAME	256
#define MAXPATH 1024

#define MAX_FILESIZE 1024 * 1024 * 256

#endif

