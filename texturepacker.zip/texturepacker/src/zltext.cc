


#include "zltext.hpp"

#include <fstream>
#include <iostream>

using namespace std;


zltext_c::zltext_c(const char *filepath)
{
	memset(m_filepath, 0, sizeof(m_filepath));
	if(filepath != NULL)
	{
		int len = 0;
		for(;;)
		{
			if(filepath[len] == '\0')
				break;
			len++;
		}
		memcpy(m_filepath, filepath, len + 1);
	}
}

zltext_c::~zltext_c()
{
}

bool zltext_c::read(const char *key, list<string> &lst)
{
	if(m_filepath[0] == '\0')
		return false;
	ifstream in(m_filepath);
	if(in.fail())
	{
		cerr << "failed to open file: " << m_filepath << endl;
		return false;
	}

	string target = "#" + string(key);
	bool find = false;
	string line;
	for(;;)
	{
		line.clear();
		getline(in, line);
		if(in.eof() || in.fail())
			break;
		if(line.size() < 2)
			continue;
		if(line[0] == '#')
		{
			if(find)
				break;

			if(target == line)
				find = true;
		}

		if(!find)
			continue;

		if(line[0] != '@')
			continue;

		lst.push_back(line.substr(1));
	}

	return true;
}

bool zltext_c::write(map<string, list<string> > &data)
{
	if(data.size() == 0)
		return false;

	if(m_filepath[0] == '\0')
		return false;
	ofstream out(m_filepath);
	if(out.fail())
	{
		cerr << "failed to open file: " << m_filepath << endl;
		return false;
	}

	out << endl;

	map<string, list<string> >::iterator map_it;
	list<string>::iterator it;
	for(map_it = data.begin(); map_it != data.end(); map_it++)
	{
		out << "#" << map_it->first << endl;
		for(it = map_it->second.begin(); it != map_it->second.end(); it++)
		{
			out << "@" << *it << endl;
		}

		out << endl;
	}

	return true;
}



