
#ifndef _MATH_HPP_
#define _MATH_HPP_


struct rect
{
	unsigned int x;
	unsigned int y;
	unsigned int width;
	unsigned int height;

	rect()
	{
		x = 0;
		y = 0;
		width = 0;
		height = 0;
	}
};

struct vector2i
{
	int x;
	int y;

	vector2i()
	{
		x = 0;
		y = 0;
	}
};


#endif


